



    <div class="container">
        <div id="carouselExampleSlidesOnly" class="carousel slide mb-3" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo base_url('assets/img/banner1.jpg') ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo base_url('assets/img/banner2.jpg') ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo base_url('assets/img/banner3.jpg') ?>" class="d-block w-100" alt="...">
                </div>
            </div>
        </div>
    </div>



<!--main-container-->

<main>

    

    <section class="container main-container contenedor1 ">
            <div class="contenedor1">
                <article class="article1">
                    <div class="card mb-3 mt-4" style="max-width: 1300px;">
                        <div class="row no-gutters">
                            <div class="col-md-6">
                                <img src="<?php echo base_url('assets/img/article1.jpg') ?>" class="card-img" alt="...">
                            </div>
                            <div class="col-md-6 ">
                            <div class="card-body">
                                    <h5 class="card-title">YOUR DOCTOR 24 HOURS</h5>
                                    <p class="card-text">At any time, your doctor will always be in charge of your family's health.</p>
                                    <p class="card-text">We have specialist doctors who will deal with more difficult situations, but the best thing is that we always have a solution.</p>
                                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                            </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
    </section>

    <section class="container main-container contenedor2">
        <article>
        <div class="card text-center mt-3 mb-3">

            <div class="card-body request">
                <h5 class="card-title">REQUEST APPOINTMENT </h5>
                <p class="card-text">Remember that after requesting your appointment, your doctor will contact you by email or phone.</p>
                <a href="signin" class="btn btn-primary  btn-lg active" role="button" aria-pressed="true">Click Here</a>
            </div>
            </div>
        </article>
    </section>

    <section class=" main-container contenedor2">
        <article>
        <div class="card text-center mt-3 mb-3">
            <div class="card-body request">
            <img src="<?php echo base_url('assets/img/banner-main.jpg') ?>" class=" banner-main" alt="...">
            </div>
            </div>
        </article>
    </section>



    <section class="container main-container contenedor3">
        <div class="contenedor3">
            <article class="article1">
            <div class="card mb-3 mt-4" style="max-width: 1300px;">
                <div class="row no-gutters">

                    <div class="col-md-6 ">
                        <div class="card-body">
                                <h5 class="card-title">CUSTOM ADVISOR</h5>
                                <p class="card-text">Any questions, contact our public attention line and we will call you as soon as possible.</p>
                                <p class="card-text">We have specialist doctors who will deal with more difficult situations, but the best thing is that we always have a solution.</p>
                                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                                <p> <strong> CUSTOM ADVISOR: 018000-69696969 </strong></p>
                                
                        </div>
                        </div>

                        <div class="col-md-6">
                            <img src="<?php echo base_url('assets/img/callcenter.jpg') ?>" class="card-img" alt="...">
                        </div>
                        
                    </div>
                </div>
            </article>
        </div>
    </section>

</main>




