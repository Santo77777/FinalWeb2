
    <div class="">
        <form id="formulario" action="registrar.php" class="formulario mt-5" method="POST" onsubmit="return validar();">
            <div class="container contenedor-form p-5 ">

                 <h1 class="pb-3">Registration Form</h1>

                    <div class="row">
                        <div class="col-md-6">
                            <label for=" ">Name</label>
                            <input id="name" type="text" class="form-control" placeholder="First name">
                        </div>
                        <div class="col-md-6">
                            <label for=" ">Lastname</label>
                            <input id="lastname" type="text" class="form-control" placeholder="Last name">
                        </div>
                        
                    </div>

                       <!--segunda fila--> 

                       <div class="row pt-3" >

                            <div class="col-md-6">
                                <label for="">Identity  Number</label>
                                <input id="id" type="id" class="form-control"  id="exampleFormControlInput1" placeholder="Id Number">

                            </div>


                        </div>

                    <!--tercera fila--> 

                    <div class="form-group row pt-3">
                        

                        <div class="col-3">
                            <label for=" ">Date</label>
                            <input class="form-control" type="date" value="2011-08-19" id="date">
                        </div>
                    </div>

                    <!--Cuarta fila--> 
                    <div class="row pt-3" >

                        <div class="col-md-6">
                            <label for="">Residence city</label>
                            <input id="residence" type="text" class="form-control" placeholder="Residence">
                        </div>
                    </div>

                    <!--Cuarta fila--> 

                    
                    <div class="form-group row pt-3">
                        

                        <div class="col-3">
                            <label for="">Neighborhood</label>
                            <input id="neighborhood" type="text" class="form-control" placeholder="Neighborhood">
                        </div>
                    </div>

                    <!--Cuarta fila--> 
                    <div class="row pt-3" >

                        <div class="col-md-6">
                            <label for="">Telephone</label>
                            <input class="form-control" type="tel" value="1-(555)-555-5555" id="tel">

                    </div>


                </div>


                <div class="row m-md-1 mt-md-5">

                    <button id="btn" type="submit" class="btn btn-primary">Submit</button>
                    
                </div>
        </form>
    </div>



