<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TaskModel extends CI_Model {

	
	public function index()
	{
        $this->load->view('layouts/header');
        $this->load->view('login');
        /*$this->load->view('layouts/footer');*/
		
	}
}