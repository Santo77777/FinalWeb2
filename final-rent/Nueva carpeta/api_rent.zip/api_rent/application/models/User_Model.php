


<?php
class User_Model extends CI_Model{
    
        public function addUser(){
            
            $user=array(
                
                'Name'=>'Carolina',
                'Lastname'=>'Cardona Suarez',
                'Email'=>'caro@gmail.com',
                'Telephone'=>65478965
                

            );
           /* $sql = "INSERT INTO user(Name,Lastname,Email,Telephone) VALUES ('{$user['Name']}', '{$user['Lastname']}', '{$user['Email']}'), {$user['Telephone']} ";*/
            //$this->db->query ($sql);

            $this->db->insert("user",$user); //Nombre de la  Table_name, 'data'


        }

        public function updateUser(){
            $user=array(
                
                'Name'=>'Yamile',
                'Lastname'=>' Suarez',
                'Email'=>'yami@gmail.com',
                'Telephone'=>12387985
                

            );
            $this->db->where("id",2);
            $this->db->update("user",$user);
        }

        public function listUsers(){
            /*
            $this->db->select('*');
            $this->db->from('user');
            $users=$this->db->get();

            if($users->num_rows()>0){
                return $users->result();
            }
            else{
                return NULL;
            }
            */
           
            $users = $this->db->query("SELECT * FROM user")->result();
            
            //return data to controller
            return $users;
            
        }

        public function deleteUser(){
            $this->db->where('id',2);
            $this->db->delete('user');
        }

    }

?>

