<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Propiety_Model extends CI_Model {

/* 	public function index()
	{
		$this->load->view('welcome_message');
    } */
    
    public function addPropiety($estate){
        $this->db->insert("estate", $estate);
    }

    public function getPropiety(){
        $response= $this->db->query("SELECT * FROM estate")->result();
        return $response;
    }

    public function updatePropiety($estate){
        $title=$estate->title;
        $type=$estate->type;
        $email=$estate->email;
        $address=$estate->address;
        $rooms=$estate->rooms;
        $price=$estate->price;
        $area=$estate->area;
        $id=$estate->id;
        $response= $this->db->query("UPDATE estate SET name='${title}', type='${type}', email='${email}', address='${address}', rooms='${rooms}', price='${price}', area='${area}'   WHERE id={$id}");
        return $response;
    }


    public function deletePropety($id){
    $response=$this->db->query("DELETE FROM estate WHERE id = {$id->id}");
    }

  /*     public function updatePropiety($estate){
        $name=$estate->name;
        $lastname=$estate->lastname;
        $email=$estate->email;
        $type_id=$estate->type_id;
        $identification=$estate->identification;
        $password=$estate->password;
        $id=$estate->id;
        $response= $this->db->query("UPDATE propiety SET name='${name}', lastname='${lastname}', email='${email}', typy_id='${type_id}', identification='${identification}', password='${password}'   WHERE id={$id}");
        return $estate;
    } */


}
