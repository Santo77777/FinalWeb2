<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Property extends CI_Controller {

	/* public function index()
	{
		$this->load->view('welcome_message');
	} */

	public function index()
	{
		echo "Index producto controller";
    }

    #endpoint add product
    public function addPropiety(){

		

        $method= $_SERVER['REQUEST_METHOD'];

        if($method === 'POST'){

            $json=file_get_contents('php://input');
            $data=json_decode($json);
  /*           echo $data->title;
            echo $data->type;
            echo $data->address;
            echo $data->rooms;
            echo $data->price;
            echo $data->area; */


            
            //title
			if(empty($data->title && $data->type && $data->address && $data->rooms && $data->price && $data->area)){  //Estas son las VALIDACIONES

				$response =array('response'=> ' Added successfully');
				echo json_encode($response);
				
			}else{

				$this->Propiety_Model->addPropiety($data);
				http_response_code(200); // 200 significa que todo esta correcto
				header('content-type: aplication/json');
				$response =array('response'=> ' Added successfully');
				echo json_encode($response); //Convierte el array asociativo en json
            }
            
            //type

            $json=file_get_contents('php://input');
            $data=json_decode($json);


            if($data->type==""){  //Estas son las VALIDACIONES

				$response =array('response'=> ' Added successfully');
				echo json_encode($response);
				
			}else{

				$this->Propiety_Model->addPropiety($data);
				http_response_code(200); // 200 significa que todo esta correcto
				header('content-type: aplication/json');
				$response =array('response'=> ' Added successfully');
				echo json_encode($response); //Convierte el array asociativo en json
            }




            // var_dump($data);

			
        }
        else{
            http_response_code(200); // 200 significa que todo esta correcto
            header('content-type: aplication/json');
            $response =array('response'=> 'Bad request');
            echo json_encode($response); //Convierte el array asociativo en json
        }
		
        
    }
    #endpoint add get
    public function getPropiety(){

		header("Access-Control-Allow_Origin: *");
        $method= $_SERVER['REQUEST_METHOD'];

        if($method === 'GET'){
			$products=$this->Product_Model->getPropiety();
            /* var_dump($products); */

            http_response_code(200); // 200 significa que todo esta correcto
            header('content-type: aplication/json');
            $response =array('propiety'=> $products, "Status"=> true);
            echo json_encode($response); //Convierte el array asociativo en json
        }
        else{
            http_response_code(200); // 200 significa que todo esta correcto
			header('content-type: aplication/json');
            $response =array('propiety'=> [], "Status"=> false);
            echo json_encode($response); //Convierte el array asociativo en json
        }
        
    }
    #endpoint add update
    public function updatePropiety(){
        $method= $_SERVER['REQUEST_METHOD'];

        if($method === 'PUT'){

			$json=file_get_contents('php://input'); //Aca recibo los datos
            $data=json_decode($json);
			$this->Propiety_Model->updatePropiety($data);
			
            header('content-type: aplication/json');
            $response =array('response'=> 'Todo correcto');
            echo json_encode($response); //Convierte el array asociativo en json
        }
        else{
            http_response_code(200); // 200 significa que todo esta correcto
            header('content-type: aplication/json');
            $response =array('response'=> 'Bad request');
            echo json_encode($response); //Convierte el array asociativo en json
        }

    }
    #endpoint add delete
    public function deletePropiety(){
        $method= $_SERVER['REQUEST_METHOD'];

        if($method === 'DELETE'){
            $json = file_get_contents('php://input');
            $data = json_decode($json);
            $this->Propiety_Model->deletePropety($data);
            header('content-type: aplication/json');
            $response =array('response'=> 'Todo correcto');
            echo json_encode($response); //Convierte el array asociativo en json
        }
        else{
            http_response_code(200); // 200 significa que todo esta correcto
            header('content-type: aplication/json');
            $response =array('response'=> 'YEGUITA hijueputa');
            echo json_encode($response); //Convierte el array asociativo en json
        }

    }
}
