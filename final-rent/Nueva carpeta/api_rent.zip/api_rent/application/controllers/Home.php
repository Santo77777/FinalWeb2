<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	
	public function index()
	{
                $this->load->view('layouts/header');
                $this->load->view('home');
                $this->load->view('layouts/footer');
                //echo base_url();
        
		
        }
        
        public function addUser(){

                $this->User_Model->addUser();  //minuto 48:00
                $this->load->view('layouts/header');
                $this->load->view('home');
                $this->load->view('layouts/footer');
        }

       public function updateUser(){
               $this->User_Model->updateUser();
       }

       public function listUsers(){
               $users=$this->User_Model->listUsers();
               print_r($users);
       }

       public function deleteUser(){
               //$sql="DELETE FROM user WHERE id =3";
               //$this->db->query($sql);


               $this->User_Model->deleteUser();
       }
               
    

}

?>